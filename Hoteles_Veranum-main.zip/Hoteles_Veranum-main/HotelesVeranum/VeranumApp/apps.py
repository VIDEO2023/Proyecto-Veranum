from django.apps import AppConfig


class VeranumappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'VeranumApp'
