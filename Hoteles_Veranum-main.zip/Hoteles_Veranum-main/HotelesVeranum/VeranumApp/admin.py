from django.contrib import admin
from .models_generado import Cliente , Menu , Habitacion


admin.site.register(Cliente)
admin.site.register(Menu)
admin.site.register(Habitacion)