# Hoteles_Veranum
Proyecto para el ramo de ingeniería de software , en donde trabajamos un con cliente ficticio llamado hoteles veranum

Para usar el proyecto , se deberán instalar todo lo descrito en el documentos requierements.tx \

Deberemos crear el usuario que se encontrará en la carpeta CreacionUsuarios_SQL/creacion_tablas.sql
También ahí encontraremos la creación y el poblamiento de las tablas que encontraremos en CreacionUsuarios_SQL/creacion_usuarios.sql



Para poder ejecutar el entorno y poder abrir la página web en nuestro localhost tendremos que 
activar el entorno, para ello podremos ejecutar el archivo s.bat desde la consola. 

Además deberemos ejecutar el archivo m.bat que hará las migraciones necesarias
